#!/bin/bash
set -e
javac BridgeSimulator.java
java BridgeSimulator 100 10

